<?php if($errors->has($field)): ?>
    <span class="invalid-feedback" role="alert"><?php echo e($errors->first($field), false); ?></span>
<?php endif; ?>
<?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/alerts/feedback.blade.php ENDPATH**/ ?>