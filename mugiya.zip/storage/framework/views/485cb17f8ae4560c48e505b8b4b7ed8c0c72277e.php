<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Clients</h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="/clients/<?php echo e($stock->id, false); ?>/create" class="btn btn-sm btn-primary">Add Client</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="card-body">
                            <div class="">
                                <table class="table">
                                    <thead>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Purchases</th>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($client->name, false); ?></td>
                                            <td><?php echo e($client->email, false); ?></td>
                                            <td><?php echo e($client->phone_number, false); ?></td>
                                            <td><?php echo e($client->purchases, false); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'clients', 'page' => 'Clients', 'section' => '','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/clients/index.blade.php ENDPATH**/ ?>