<div class="sidebar">
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li <?php if($pageSlug == 'dashboard'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('home'), false); ?>">
                    <i class="tim-icons icon-chart-bar-32"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li <?php if($pageSlug == 'clients'): ?> class="active " <?php endif; ?>>
                <a href="/clients/<?php echo e($StockId, false); ?>">
                    <i class="tim-icons icon-single-02"></i>
                    <p>Clients</p>
                </a>
            </li>

            <li <?php if($pageSlug == 'products'): ?> class="active " <?php endif; ?>>
                <a href="/stock/products/<?php echo e($StockId, false); ?>">
                    <i class="tim-icons icon-delivery-fast"></i>
                    <p>Products</p>
                </a>
            </li>

            <li>
                <a data-toggle="collapse" href="#transactions" <?php echo e($section == 'transactions' ? 'aria-expanded=true' : '', false); ?>>
                    <i class="tim-icons icon-bank" ></i>
                    <span class="nav-link-text">Transactions</span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse <?php echo e($section == 'transactions' ? 'show' : '', false); ?>" id="transactions">
                    <ul class="nav pl-4">






                        <li <?php if($pageSlug == 'cart'): ?> class="active " <?php endif; ?>>
                            <a href="/cart/<?php echo e($StockId, false); ?>/">
                                <i class="tim-icons icon-cart"></i>
                                <p>Cart</p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'stockhistory'): ?> class="active " <?php endif; ?>>
                            <a href="/stock_history/<?php echo e($StockId, false); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p>Stock History</p>
                            </a>
                        </li>


                    </ul>
                </div>
            </li>
            <li>
                <a data-toggle="collapse" href="#debt" <?php echo e($section == 'debt' ? 'aria-expanded=true' : '', false); ?>>
                    <i class="tim-icons icon-bank" ></i>
                    <span class="nav-link-text">Debt</span>
                    <b class="caret mt-1"></b>
                </a>
                <div class="collapse <?php echo e($section == 'debt' ? 'show' : '', false); ?>" id="debt">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'cart'): ?> class="active " <?php endif; ?>>
                            <a href="/create_debt/<?php echo e($StockId, false); ?>">
                                <i class="tim-icons icon-cart"></i>
                                <p> Create Debt</p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'cart'): ?> class="active " <?php endif; ?>>
                            <a href="/debt_cart/<?php echo e($StockId, false); ?>/">
                                <i class="tim-icons icon-cart"></i>
                                <p>Add Products To Debt</p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'stockhistory'): ?> class="active " <?php endif; ?>>
                            <a href="/debt_history/<?php echo e($StockId, false); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p>Debt History</p>
                            </a>
                        </li>


                    </ul>
                </div>
            </li>



        </ul>
    </div>
</div>
<?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/layouts/navbars/nav2.blade.php ENDPATH**/ ?>