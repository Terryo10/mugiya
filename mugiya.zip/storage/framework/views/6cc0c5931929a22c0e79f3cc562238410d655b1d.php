<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">You are currently managing <?php echo e($stock->name, false); ?></div>

                    <div class="card-body">
                        <div class="card-body">
                            <div class="">
                                <table class="table">
                                    <thead>
                                    <th>currently sold</th>
                                    <th>Anticipated in stock</th>

                                    <th>Total Debt </th>
                                    <th>Products debted</th>
                                    <th>Products in stock after debt</th>
                                    <th>Stock Expenses</th>
                                    <th>Stock Discounts</th>
                                    <th>Total Amount Earned</th>
                                    <th>Status</th>
                                    </thead>
                                    <tbody>
                                    <td><?php echo e($productsSold, false); ?></td>
                                    <td><?php echo e($productsLeftInStock, false); ?></td>

                                  <td>$ <?php echo e(number_format($totalDebt, 2, ',', '.'), false); ?></td>
                                  <td><?php echo e($totalDebtProducts, false); ?></td>
                                  <td><?php echo e($productsLeftInStock - $totalDebtProducts, false); ?></td>
                                  <td><?php echo e($totalExpense, false); ?></td>
                                  <td><?php echo e($totalDiscount, false); ?></td>
                                  <td>$ <?php echo e(number_format(($totalAmountSold - $totalExpense ) - $totalDiscount, 2, ',', '.'), false); ?></td>
                                    <td><?php if($stock->status): ?>
                                    Products Available in stock
                                        <?php else: ?>

                                        No Products in stock
                                        <?php endif; ?>
                                    </td>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', ['pageSlug' => 'stock', 'page' => 'Stock Management', 'section' => '','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/management.blade.php ENDPATH**/ ?>