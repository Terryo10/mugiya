<!doctype html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <title>Invoice - #123</title>

    <style type="text/css">
        @page  {
            margin: 0px;
        }
        body {
            margin: 0px;
        }
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        a {
            color: #fff;
            text-decoration: none;
        }
        table {
            font-size: x-small;
        }
        tfoot tr td {
            font-weight: bold;
            font-size: x-small;
        }
        /* .invoice table {
            margin: 155px;
        } */
        .invoice h3 {
            margin-left: 15px;
        }
        .information {
            background-color: #60A7A6;
            color: #FFF;
        }
        .information .logo {
            margin: 5px;
        }
        .information table {
            padding: 10px;
        }
    </style>

</head>
<body>

<div class="information">
    <table width="100%">
        <tr>
            <td align="left" style="width: 40%;">
                <h3><?php echo e($client->name, false); ?></h3>
                <pre>
Show Grounds
Harare
Zimbabwe
<br /><br />
Date: <?php echo e(Carbon\Carbon::now(), false); ?>

Identifier: <?php echo e(uniqid(), false); ?>


</pre>


            </td>
            <td align="center">
                
            </td>
            <td align="right" style="width: 40%;">

                
            </td>
        </tr>

    </table>
</div>


<br/>

<div class="invoice">
    <h3>Invoice specification</h3>
    <table >
        <thead>
        <tr>
            <th>Item</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaction->transactionItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->product->name, false); ?></td>
                <td><?php echo e($product->quantity, false); ?></td>
                <td align="left">$ <?php echo e(number_format($product->price * $product->quantity, 2, ',', '.'), false); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>

        <tfoot>
        <tr>
            <td colspan="1"></td>
            <td align="left">Total</td>
            <td align="left" class="gray">$ <?php echo e(number_format($total, 2, ',', '.'), false); ?></td>
        </tr>
        </tfoot>
    </table>
</div>

<div class="information" style="position: absolute; bottom: 0;">
    <table width="100%">
        <tr>
            <td align="left" style="width: 50%;">
                &copy; <?php echo e(date('Y'), false); ?> <?php echo e(config('app.url'), false); ?> - All rights reserved.
            </td>
            <td align="right" style="width: 50%;">
                Migiya Sys
            </td>
        </tr>

    </table>
</div>
</body>
</html>
<?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/invoice.blade.php ENDPATH**/ ?>