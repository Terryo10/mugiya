<?php $__env->startSection('content'); ?>
      <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Transaction <?php echo e($debt->created_at->format('l jS \\of F Y h:i:s A'), false); ?></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="" class="btn btn-sm btn-primary">
                                amount paid $<?php echo e($debt->amount_paid, false); ?>

                            </a>
                            <a href="" class="btn btn-sm btn-primary">
                                amount to be paid $<?php echo e($total - $debt->amount_paid, false); ?>

                            </a>
                            <a href="" class="btn btn-sm btn-primary">
                                total $<?php echo e($total, false); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                        <table class="table">
                            <thead>
                                <th>name</th>
                                <th>Description</th>
                                <th>total price per item</th>
                                <th>Quantity</th>
                                <th>Price</th>

                            </thead>
                            <tbody>
                                
                            <?php $__currentLoopData = $debt->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->product->name, false); ?></td>
                                        <td><?php echo e($transaction->product->description, false); ?></td>
                                        <td><?php echo e($transaction->quantity * $transaction->price, false); ?></td>
                                        <td><?php echo e($transaction->quantity, false); ?></td>
                                        <td>$ <?php echo e($transaction->price, false); ?></td>

                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>

       <div class="row">
        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Buying Client</h4>
                        </div>
                        <div class="col-4 text-right">

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-full-width table-responsive">
                        <table class="table">
                            <thead>
                                <th>Name</th>
                                <th>phone_number</th>
                                <th>Email</th>
                            </thead>
                            <tbody>

                                    <tr>
                                        <td><?php echo e($debt->name, false); ?></td>
                                        <td><?php echo e($debt->phone_number, false); ?></td>
                                        <td><?php echo e($debt->email, false); ?></td>


                                    </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Method Used To Pay</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="/settle/<?php echo e($debt->id, false); ?>" class="btn btn-sm btn-primary">Settle Debt</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'debt', 'page' => 'Debt', 'section' => '','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/debts/show.blade.php ENDPATH**/ ?>