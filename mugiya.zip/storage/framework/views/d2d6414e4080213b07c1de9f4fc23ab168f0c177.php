<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Select Stock'), false); ?></div>

                <div class="card-body">
                    <div class="card-body">
                        <div class="">
                            <table class="table">
                                <thead>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Action</th>
                                <th>Status</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($stock->name, false); ?></td>
                                    <td><?php echo e($stock->created_at, false); ?></td>
                                        <?php if($stock->status == 0): ?>
                                            <td> <a href="" class="btn btn-sm btn-primary">Preview Stock History</a></td>
                                        <?php else: ?>
                                            <td> <a href="/stock/managment/<?php echo e($stock->id, false); ?>" class="btn btn-sm btn-primary">Manage</a></td>
                                        <?php endif; ?>

                                        <?php if($stock->status == 0): ?>
                                    <td>Sold Out</td>
                                        <?php else: ?>
                                            <td>Products For Sale Still Available</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard', 'page' => 'Dashboard', 'section' => '', ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/home.blade.php ENDPATH**/ ?>