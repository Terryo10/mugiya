<?php $__env->startSection('content'); ?>
    <div>
        <div class="pl-lg-4">
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
            <div  >
                <label class="form-control-label" for="input-price">Products in cart Products</label>
                <div class="container">
                    <div class="col-4 text-right">
                        <a href="/payments/<?php echo e($stock->id, false); ?>/create" class="btn btn-sm btn-primary">Add more Products in Cart</a>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div >
                                <table class="table table-bordered">
                                    <thead>
                                    <div>
                                        <p>Products Search</p>
                                        <input class="form-control" id="myInput" type="text" placeholder="Search..">
                                        <br>
                                    </div>
                                    <tr>
                                        <th scope="col">Product Name</th>

                                        <th scope="col">Qty In Cart</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Total per item</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                     <?php if($cart == null || $cart->cart_items == []): ?>
                                     <?php else: ?>
                                          <?php $__currentLoopData = $cart->cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div id="myList" class="custom-control custom-checkbox">
                                                    <label  class="custom-control-label" for="customCheck1"><?php echo e($product->product->name, false); ?></label>
                                                </div>
                                            </td>

                                            <td><?php echo e($product->quantity, false); ?></td>
                                            <td>$<?php echo e($product->price, false); ?></td>
                                            <td>$<?php echo e($product->price * $product->quantity, false); ?></td>
                                            <td><form method="post" action="/delete_cart_item">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($product->id, false); ?>" name="cart_item_id">
                                                    <button class="btn-sm btn-success">Remove from cart</button></form>
                                                <form method="post" action="/decrement">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($product->product->id, false); ?>" name="product_id">
                                                <button class="btn-sm btn-danger">Decrement</button>
                                                </form>
                                                <form method="post" action="/increment">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($product->product->id, false); ?>" name="product_id">
                                                    <button class="btn-sm btn-default">increment</button>
                                                </form> </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php endif; ?>

                                    </tbody>

                                </table>
                            </div>
                            <div>
                                <div class="alert alert-success" role="alert">
                                    <center>Total $ <?php echo e($total, false); ?></center>
                                </div>
                            </div>

                            <?php if($cart == null || $cart->cart_items == []): ?>
                                    <div>
                                <div class="alert alert-success" role="alert">
                                    <center>You dont have products in cart</center>
                                </div>
                            </div>
                                <?php else: ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                       <form method="post" action="/payments/<?php echo e($stock->id, false); ?>">
                                           <?php echo csrf_field(); ?>
                                          <div class="pl-lg-4">
                                            <div class="form-group<?php echo e($errors->has('client_id') ? ' has-danger' : '', false); ?>">
                                            <label for="exampleInputEmail1" class="form-label">Select Client</label>
                                              <div class="form-control-label col-md-12" >
                                                     <select name="client_id" id="input-category" class="form-select form-control-alternative<?php echo e($errors->has('client_id') ? ' is-invalid' : '', false); ?>" required>
                                                         <option>Select Client</option>
                                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($client->id, false); ?>"><?php echo e($client->name, false); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                     </select>
                                              </div>
                                            </div>
                                          <div class="mb-3">
                                            <label for="exampleInputPassword1" class="form-label">Payment Method</label>
                                               <div class="form-control-label col-md-12" >
                                            <select name="payment_method" id="input-category" class="form-select form-control-alternative<?php echo e($errors->has('payment_method') ? ' is-invalid' : '', false); ?>" required>
                                                         <option>Select Payment Method</option>
                                                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($method->id, false); ?>"><?php echo e($method->name, false); ?></option>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                     </select>
                                               </div>
                                          </div>
                                              <input type="hidden" name="stock_id" value="<?php echo e($stock->id, false); ?>">
                                          <button type="submit" class="btn btn-primary">Make Transaction</button>
                                          </div>
                                        </form>
                                        </div>
                                    </div>


                            <?php endif; ?>
                            <div></div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'cart', 'page' => 'Cart Page ', 'section' => 'transactions','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/cart.blade.php ENDPATH**/ ?>