<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">You are currently products in <?php echo e($stock->name, false); ?></div>

                    <div class="card-body">
                        <div class="card-body">
                            <div class="">
                                <table class="table">
                                    <thead>
                                    <th>Name</th>
                                    <th>Date</th>
                                    <th>Quantity in Stock</th>
                                    <th>Price</th>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $stock->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($products->name, false); ?></td>
                                            <td><?php echo e($products->created_at, false); ?></td>
                                            <td><?php echo e($products->quantity_in_stock, false); ?></td>
                                            <td>$ <?php echo e($products->price, false); ?></td>


                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'products', 'page' => 'Products', 'section' => '','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/products.blade.php ENDPATH**/ ?>