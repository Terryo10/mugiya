<?php $__env->startSection('content'); ?>
      <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Transaction for <?php echo e($stock->name, false); ?></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="" class="btn btn-sm btn-primary">
                                Stock Expenses
                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                        <table class="table">
                            <thead>
                                <th>name</th>
                                <th>for</th>
                                <th>Action</th>

                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transactions->created_at->format('l jS \\of F Y h:i:s A'), false); ?></td>
                                        <td><?php echo e(\App\Models\customer::find($transactions->client_id)->name, false); ?></td>
                                    <td><a href="/get_transaction?stock_id=<?php echo e($stock->id, false); ?>&transaction_id=<?php echo e($transactions->id, false); ?>" class="btn btn-sm btn-primary">
                                preview
                            </a></td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'stockhistory', 'page' => $stock->name, 'section' => '','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/stock_history.blade.php ENDPATH**/ ?>