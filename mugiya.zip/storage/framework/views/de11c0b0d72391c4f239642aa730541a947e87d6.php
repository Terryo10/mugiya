<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"> Enter New Debt</h3>
                        </div>

                    </div>
                </div>

                <div class="card-body">
                    <div class="card-body">
                    <div class="card-body">
                        <form method="post" action="/debt_store/<?php echo e($stock->id, false); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>

                            <div class="pl-lg-4">

                                <div class="form-group<?php echo e($errors->has('product_id') ? ' has-danger' : '', false); ?>">
                                    <label class="form-control-label" for="input-price">Name Of Client</label>
                                    <input type="name" name="name" id="input-price" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : '', false); ?>" value="" required>
                                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : '', false); ?>">
                                    <label class="form-control-label" for="input-price">Amount Paid</label>
                                    <input type="number" name="amount_paid" id="input-price" class="form-control form-control-alternative<?php echo e($errors->has('amount_paid') ? ' is-invalid' : '', false); ?>" value="" required>
                                    <?php echo $__env->make('alerts.feedback', ['field' => 'amount_paid'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('product_id') ? ' has-danger' : '', false); ?>">
                                    <label class="form-control-label" for="input-qty">Phone Number</label>
                                    <input type="tel" name="phone_number" id="input-qty" class="form-control form-control-alternative<?php echo e($errors->has('phone_number') ? ' is-invalid' : '', false); ?>"  required>
                                    <?php echo $__env->make('alerts.feedback', ['field' => 'phone_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-success mt-4">Create</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', ['pageSlug' => 'debt', 'page' => 'Create New Debt ', 'section' => 'debt','StockId'=> $stock->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tererai/Documents/projects/mugiya/resources/views/pages/debts/create.blade.php ENDPATH**/ ?>